const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 8e6 });
app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_, res) => res.json({ ok: true }));
const rooms = new Map();
const MAX_PEOPLE = 5;
function roomFor(code) { if (!rooms.has(code)) rooms.set(code, { strokes: [], members: new Map() }); return rooms.get(code); }
function code() { let s=''; const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; for(let i=0;i<6;i++) s+=chars[Math.floor(Math.random()*chars.length)]; return s; }
io.on('connection', socket => {
  socket.on('create-room', (name, cb) => {
    let c; do { c=code(); } while(rooms.has(c));
    joinRoom(socket,c,name,cb);
  });
  socket.on('join-room', ({code:c,name}, cb) => joinRoom(socket, String(c||'').toUpperCase().trim(), name, cb));
  socket.on('stroke-start', data => {
    const c=socket.data.room; if(!c || !validStroke(data)) return;
    const room=roomFor(c); const stroke={id:data.id, owner:socket.id, color:data.color, size:data.size, tool:data.tool, points:[data.point]}; room.strokes.push(stroke); socket.to(c).emit('stroke-start', stroke);
  });
  socket.on('stroke-points', ({id,points}) => {
    const c=socket.data.room; if(!c || !Array.isArray(points)||points.length>300) return;
    const room=roomFor(c); const s=room.strokes.find(x=>x.id===id && x.owner===socket.id); if(s){ s.points.push(...points.slice(0,300)); socket.to(c).emit('stroke-points',{id,points}); }
  });
  socket.on('stroke-end', id => { const c=socket.data.room; if(c) socket.to(c).emit('stroke-end',id); });
  socket.on('undo', () => { const c=socket.data.room; if(!c)return; const r=roomFor(c); const i=r.strokes.map(s=>s.owner).lastIndexOf(socket.id); if(i>=0){ const [s]=r.strokes.splice(i,1); io.to(c).emit('remove-stroke',s.id); }});
  socket.on('clear-canvas', () => { const c=socket.data.room; if(c){ roomFor(c).strokes=[]; io.to(c).emit('clear-canvas'); }});
  socket.on('disconnect', () => { const c=socket.data.room; if(!c)return; const r=rooms.get(c); if(!r)return; r.members.delete(socket.id); io.to(c).emit('people', [...r.members.values()]); if(!r.members.size) rooms.delete(c); });
});
function validStroke(d){ return d && typeof d.id==='string' && d.id.length<100 && typeof d.color==='string' && d.color.length<30 && Number(d.size)>0 && Number(d.size)<100 && ['pen','marker','eraser'].includes(d.tool) && d.point && Number.isFinite(d.point.x)&&Number.isFinite(d.point.y); }
function joinRoom(socket,c,name,cb){
  if(!c || !/^[A-Z0-9]{6}$/.test(c)){ cb?.({ok:false,error:'Código inválido. Use 6 letras ou números.'}); return; }
  const r=roomFor(c); if(r.members.size>=MAX_PEOPLE){ cb?.({ok:false,error:'Essa sala já está cheia (5 pessoas).'}); return; }
  const cleanName=String(name||'Artista').trim().slice(0,18)||'Artista'; socket.join(c); socket.data.room=c;
  r.members.set(socket.id,{id:socket.id,name:cleanName});
  // Owner id added for undo bookkeeping
  r.strokes.forEach(s=>{ if(!s.owner) s.owner=''; });
  cb?.({ok:true,code:c,people:[...r.members.values()],strokes:r.strokes}); io.to(c).emit('people',[...r.members.values()]);
}
// Attach owner to strokes from sender via socket data before storing
const oldOn = io;
server.listen(process.env.PORT || 3000, () => console.log('DrawTogether listening'));
