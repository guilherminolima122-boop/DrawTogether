# DrawTogether (MVP)

Aplicativo web instalável para desenhar em salas com até 5 participantes.

## Rodar localmente
1. Instale Node.js 18 ou mais recente.
2. No terminal, dentro desta pasta: `npm install`
3. Depois: `npm start`
4. Abra `http://localhost:3000`.

Para testar em dois celulares na mesma rede Wi-Fi, abra no computador o endereço local dele na porta 3000 (ex.: `http://192.168.0.10:3000`). Para acesso de fora da rede, hospede este projeto em um serviço que aceite Node.js e WebSockets.

## Deploy (Render)
- Crie um Web Service apontando para o repositório.
- Build command: `npm install`
- Start command: `npm start`
- O Render define `PORT` automaticamente.

Depois de publicado em HTTPS, abra no Android Chrome e use menu ⋮ > Adicionar à tela inicial / Instalar.

## Recursos MVP
- Salas com código de 6 caracteres, até 5 pessoas.
- Traços sincronizados ao vivo.
- Caneta, marcador, borracha, cores, espessura.
- Desfazer último traço do participante atual.
- Limpar folha (ação compartilhada).
- Zoom, exportar PNG e carregar imagem de referência local.

Observação: carregamento de imagem é local nesta versão; preenchimento por balde, armazenamento permanente de salas, zoom/pan com gesto de dois dedos e sincronização da imagem de referência serão implementados numa próxima versão.
